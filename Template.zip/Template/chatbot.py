import os
from openai import OpenAI


messages = [{"role": "system","content": "You are an AI helper bot who helps clients understand what our company does. Our company is Accelerate Foundatoin, also known as ACFN, and we provide website services to clients who request them. IT IS EXTREMELY IMPORTANT TO REMEMBER THAT, If the user asks something unrelated to the website, make sure to say something along the lines of, I cannot help with that. Make the reponces in medium length so that the client doesn't get frustrated."}]

# possibly try and add a system that clears these messages every time because they are being saved after ever message

def chatbotfunctionpython(userinput):
    client = OpenAI(
        # This is the default and can be omitted
        api_key="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",
    )
    

    # while True:

    messages.append({"role": "user","content": userinput})

    chat_completion = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=messages
    )

    responce = chat_completion.choices[0].message.content
    messages.append({"role": "assistant", "content": responce})
    print(messages)
    return responce