from flask import Flask, render_template, url_for, request, jsonify
import chatbot
from flask_cors import CORS

app = Flask(__name__)
CORS(app)



@app.route("/home", methods=['POST', 'GET'])
def home():

    # store chat box content in something called Web Storage (https://www.webfx.com/blog/web-design/web-storage-primer/#:~:text=sessionStorage%20%2C%20in%20practice%2C%20is%20best,of%20the%20user's%20browsing%20session.)
    global chat_history
    chat_history = []
    return render_template('main.html')

@app.route("/aboutus")
def aboutus():
    return render_template('aboutus.html')

@app.route("/contactus")
def contactus():
    return render_template('contact.html')

@app.route("/login")
def login():
    return render_template('login.php')


@app.route("/chatoutput", methods=['POST', 'GET'])
def chatoutput():
    if request.method == "POST":
        userinput = request.form.getlist('userinput')[0]
        chatresponce = chatbot.chatbotfunctionpython(userinput)
        print(chatresponce)
        
        chat_history.append({"userinput": userinput, "chatresponce": chatresponce})
        return jsonify({'chat_history': chat_history})
     
if __name__ == "__main__":
    app.run(debug=True)