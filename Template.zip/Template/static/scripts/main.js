window.addEventListener("scroll", function () {
  var header = document.querySelector("header");
  header.classList.toggle("sticky", window.scrollY > 0);
})

window.addEventListener("scroll", function () {
  var header = document.querySelector(".chatbox");
  header.classList.toggle("sticky", window.scrollY > 0);
  if (window.scrollY > 10) {
    header.style.visibility = "visible"
  } else {
    header.style.visibility = "hidden"
  }

  // uncomment out code later
})

window.addEventListener("load", () => {
  const loader = document.querySelector(".loader");
  // document.documentElement.scrollTop = 0;
  setTimeout(() => {
    loader.classList.add("loader--hidden");
    loader.addEventListener("transitionend", () => {
      if (document.querySelector(".loader")) {
        document.body.removeChild(loader);
        document.body.style.overflow = "visible";
      }
    });
  }, 1000);
});

// Form JS
var signupelement = document.querySelector(".signuplink")
var signinelement = document.querySelector(".signinlink")

var signup = document.querySelector(".signup")
var login = document.querySelector(".login")

signupelement.addEventListener('click', () => {
  login.style.display = 'none'
  login.style.visibility = 'hidden'
  signup.style.visibility = 'visible'
  signup.style.margin = '24vh 0 24vh 0'
  signup.style.display = "flex"
})

signinelement.addEventListener('click', () => {
  signup.style.display = 'none'
  signup.style.visibility = 'hidden'
  login.style.visibility = 'visible'
  login.style.margin = '24vh 0 24vh 0'
  login.style.display = "flex"
})

// index.html page to login.html buttons functionality
function signinclick() {
  window.location.href = "/Programming/Template/webpages/login.php"
}

function signupclick() {
  window.location.href = "/Programming/Template/webpages/login.php"
  login.style.display = 'none'
  login.style.visibility = 'hidden'
  signup.style.visibility = 'visible'
  signup.style.margin = '24vh 0 24vh 0'
  signup.style.display = "flex"

  // needs to be fixed


}



function chatbotbuttonclick1() {
  var chat = document.querySelector(".chat")
  var chatbut1 = document.querySelector(".chatbuttonshow")
  var chatbut2 = document.querySelector(".chatbuttonhide")
  var chatform = document.querySelector(".chatform")
  var chatoutput = document.querySelector(".chatoutput")

  chat.style.display = "block"
  chatoutput.style.height = "40vh"
  chatbut1.style.display = "none"
  chatbut2.style.display = "block"
  chatform.style.display = "block"
  // chatoutput.style.display = "block"
}


function chatbotbuttonclick2() {
  var chat = document.querySelector(".chat")
  var chatbut1 = document.querySelector(".chatbuttonshow")
  var chatbut2 = document.querySelector(".chatbuttonhide")
  var chatform = document.querySelector(".chatform")
  var chatoutput = document.querySelector(".chatoutput")

  chat.style.display = "none"
  chatoutput.style.height = "0"
  chatbut2.style.display = "none"
  chatbut1.style.display = "block"
  chatform.style.display = "none"
  // chatoutput.style.display = "none"
}



// window.onload = function () {
// //   var gptchatbox = document.querySelector(".chatform")
//   var userinputentered = document.querySelector(".chatinput")
//   var chatoutput = document.querySelector(".chatoutput")
//   gptchatbox.onsubmit = function (e) {
//     e.preventDefault()
//     // chatoutput.append("<p>"+userinputentered.value+"</p>")

//     var userInput = userinputentered.value

//     fetch("/chatoutput", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({ command: userInput }),
//     })
//       .then(response => response.json())
//       .then(textoutput => {
//         // chatoutput.append("<p>"+textoutput+"</p>")
//         console.log(textoutput)
//       })
//       .catch(error => console.error('Error:', error));
//   }
// }



// window.addEventListener("reload", () => {
//   $('.chatoutput').empty()
// })

function outputfunc(event) {
  event.preventDefault()
  var userinputentered = document.querySelector(".chatinput")

  $.ajax({
    type: "POST",
    url: "/chatoutput",
    data: { "userinput": userinputentered.value },
    contentType: 'application/x-www-form-urlencoded',  
    success: function(data) {
      var chathistory = data.chat_history

      $('.chatoutput').empty()

      chathistory.forEach(function(pair) {
        $('.chatoutput').append(
          `<p>User Input: ${pair.userinput}</p><br>` +
          `<p>Chatbot Output: ${pair.chatresponce}</p><br>`
        )
      });
    }
  })
}

// $('.chatform').submit(function(event) {
  
// });