var signup = document.querySelector(".signup")

signup.addEventListener('submit', event => {
    
})